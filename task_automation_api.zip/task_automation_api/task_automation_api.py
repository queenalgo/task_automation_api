from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
import subprocess
import psutil
import os
import json
import logging
from datetime import datetime
import asyncio
from enum import Enum

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Task Automation API",
    description="API for automating server tasks and system management",
    version="1.0.0"
)

# Security
security = HTTPBearer()

# Configuration - In production, use environment variables
API_TOKEN = os.getenv("API_TOKEN", "your-secret-token-here")

class TaskType(str, Enum):
    RESTART_SERVER = "restart_server"
    CHECK_STATUS = "check_status"
    RESTART_SERVICE = "restart_service"
    CHECK_DISK_SPACE = "check_disk_space"
    CHECK_MEMORY = "check_memory"
    RUN_COMMAND = "run_command"
    CHECK_LOGS = "check_logs"

class TaskRequest(BaseModel):
    task_type: TaskType
    parameters: Optional[Dict[str, Any]] = {}

class TaskResponse(BaseModel):
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = {}
    timestamp: str = datetime.now().isoformat()

class SystemStatus(BaseModel):
    cpu_percent: float
    memory_percent: float
    disk_usage: Dict[str, Any]
    uptime: str
    running_processes: int

# Authentication dependency
def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if credentials.credentials != API_TOKEN:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token"
        )
    return credentials.credentials

# Utility functions
def run_command(command: str, timeout: int = 30) -> Dict[str, Any]:
    """Execute a shell command safely"""
    try:
        result = subprocess.run(
            command.split(),
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return {
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr
        }
    except subprocess.TimeoutExpired:
        return {"error": "Command timed out"}
    except Exception as e:
        return {"error": str(e)}

def get_system_status() -> SystemStatus:
    """Get current system status"""
    # Get disk usage for root partition
    disk_usage = psutil.disk_usage('/')
    disk_info = {
        "total": disk_usage.total,
        "used": disk_usage.used,
        "free": disk_usage.free,
        "percent": (disk_usage.used / disk_usage.total) * 100
    }
    
    # Get uptime
    boot_time = datetime.fromtimestamp(psutil.boot_time())
    uptime = str(datetime.now() - boot_time)
    
    return SystemStatus(
        cpu_percent=psutil.cpu_percent(interval=1),
        memory_percent=psutil.virtual_memory().percent,
        disk_usage=disk_info,
        uptime=uptime,
        running_processes=len(psutil.pids())
    )

# Task handlers
class TaskHandler:
    @staticmethod
    def restart_server(parameters: Dict[str, Any]) -> TaskResponse:
        """Restart the server (use with caution!)"""
        delay = parameters.get("delay", 5)
        logger.warning(f"Server restart requested with {delay}s delay")
        
        # In a real environment, you might want additional safety checks
        if parameters.get("confirm", False):
            # Schedule restart
            command = f"sudo shutdown -r +{delay//60}"
            result = run_command(command)
            
            if result.get("returncode") == 0:
                return TaskResponse(
                    success=True,
                    message=f"Server restart scheduled in {delay} seconds",
                    data={"delay": delay}
                )
            else:
                return TaskResponse(
                    success=False,
                    message="Failed to schedule server restart",
                    data=result
                )
        else:
            return TaskResponse(
                success=False,
                message="Server restart requires confirmation parameter"
            )
    
    @staticmethod
    def check_status(parameters: Dict[str, Any]) -> TaskResponse:
        """Check system status"""
        try:
            status = get_system_status()
            return TaskResponse(
                success=True,
                message="System status retrieved successfully",
                data=status.dict()
            )
        except Exception as e:
            return TaskResponse(
                success=False,
                message=f"Failed to get system status: {str(e)}"
            )
    
    @staticmethod
    def restart_service(parameters: Dict[str, Any]) -> TaskResponse:
        """Restart a system service"""
        service_name = parameters.get("service_name")
        if not service_name:
            return TaskResponse(
                success=False,
                message="service_name parameter is required"
            )
        
        # Restart service using systemctl
        result = run_command(f"sudo systemctl restart {service_name}")
        
        if result.get("returncode") == 0:
            return TaskResponse(
                success=True,
                message=f"Service {service_name} restarted successfully"
            )
        else:
            return TaskResponse(
                success=False,
                message=f"Failed to restart service {service_name}",
                data=result
            )
    
    @staticmethod
    def check_disk_space(parameters: Dict[str, Any]) -> TaskResponse:
        """Check disk space usage"""
        path = parameters.get("path", "/")
        try:
            disk_usage = psutil.disk_usage(path)
            data = {
                "path": path,
                "total_gb": round(disk_usage.total / (1024**3), 2),
                "used_gb": round(disk_usage.used / (1024**3), 2),
                "free_gb": round(disk_usage.free / (1024**3), 2),
                "percent_used": round((disk_usage.used / disk_usage.total) * 100, 2)
            }
            return TaskResponse(
                success=True,
                message="Disk space checked successfully",
                data=data
            )
        except Exception as e:
            return TaskResponse(
                success=False,
                message=f"Failed to check disk space: {str(e)}"
            )
    
    @staticmethod
    def check_memory(parameters: Dict[str, Any]) -> TaskResponse:
        """Check memory usage"""
        try:
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()
            
            data = {
                "memory": {
                    "total_gb": round(memory.total / (1024**3), 2),
                    "used_gb": round(memory.used / (1024**3), 2),
                    "free_gb": round(memory.free / (1024**3), 2),
                    "percent_used": memory.percent
                },
                "swap": {
                    "total_gb": round(swap.total / (1024**3), 2),
                    "used_gb": round(swap.used / (1024**3), 2),
                    "free_gb": round(swap.free / (1024**3), 2),
                    "percent_used": swap.percent
                }
            }
            return TaskResponse(
                success=True,
                message="Memory usage checked successfully",
                data=data
            )
        except Exception as e:
            return TaskResponse(
                success=False,
                message=f"Failed to check memory: {str(e)}"
            )
    
    @staticmethod
    def run_command(parameters: Dict[str, Any]) -> TaskResponse:
        """Run a custom command (restricted for security)"""
        command = parameters.get("command")
        if not command:
            return TaskResponse(
                success=False,
                message="command parameter is required"
            )
        
        # Whitelist of safe commands (expand as needed)
        safe_commands = [
            "ps", "top", "df", "free", "uptime", "whoami", "date",
            "systemctl status", "docker ps", "docker stats"
        ]
        
        if not any(command.startswith(safe_cmd) for safe_cmd in safe_commands):
            return TaskResponse(
                success=False,
                message="Command not in whitelist for security reasons"
            )
        
        result = run_command(command)
        return TaskResponse(
            success=result.get("returncode") == 0,
            message="Command executed",
            data=result
        )
    
    @staticmethod
    def check_logs(parameters: Dict[str, Any]) -> TaskResponse:
        """Check recent log entries"""
        log_file = parameters.get("log_file", "/var/log/syslog")
        lines = parameters.get("lines", 50)
        
        try:
            result = run_command(f"tail -{lines} {log_file}")
            return TaskResponse(
                success=True,
                message=f"Retrieved last {lines} lines from {log_file}",
                data={"logs": result.get("stdout", "")}
            )
        except Exception as e:
            return TaskResponse(
                success=False,
                message=f"Failed to read logs: {str(e)}"
            )

# Routes
@app.get("/")
def read_root():
    return {"message": "Task Automation API", "status": "running"}

@app.get("/health")
def health_check():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

@app.post("/execute", response_model=TaskResponse)
def execute_task(
    task_request: TaskRequest, 
    token: str = Depends(verify_token)
) -> TaskResponse:
    """Execute a task based on the request"""
    
    logger.info(f"Executing task: {task_request.task_type} with parameters: {task_request.parameters}")
    
    handler = TaskHandler()
    
    # Route to appropriate handler
    if task_request.task_type == TaskType.RESTART_SERVER:
        return handler.restart_server(task_request.parameters)
    elif task_request.task_type == TaskType.CHECK_STATUS:
        return handler.check_status(task_request.parameters)
    elif task_request.task_type == TaskType.RESTART_SERVICE:
        return handler.restart_service(task_request.parameters)
    elif task_request.task_type == TaskType.CHECK_DISK_SPACE:
        return handler.check_disk_space(task_request.parameters)
    elif task_request.task_type == TaskType.CHECK_MEMORY:
        return handler.check_memory(task_request.parameters)
    elif task_request.task_type == TaskType.RUN_COMMAND:
        return handler.run_command(task_request.parameters)
    elif task_request.task_type == TaskType.CHECK_LOGS:
        return handler.check_logs(task_request.parameters)
    else:
        return TaskResponse(
            success=False,
            message=f"Unknown task type: {task_request.task_type}"
        )

@app.get("/tasks")
def list_available_tasks(token: str = Depends(verify_token)):
    """List all available task types"""
    return {
        "available_tasks": [task.value for task in TaskType],
        "descriptions": {
            "restart_server": "Restart the server (requires confirmation)",
            "check_status": "Get system status (CPU, memory, disk, uptime)",
            "restart_service": "Restart a system service",
            "check_disk_space": "Check disk space usage",
            "check_memory": "Check memory and swap usage",
            "run_command": "Run whitelisted commands",
            "check_logs": "Check recent log entries"
        }
    }

@app.get("/status")
def get_system_status_endpoint(token: str = Depends(verify_token)):
    """Get current system status"""
    try:
        status = get_system_status()
        return {"success": True, "data": status.dict()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)