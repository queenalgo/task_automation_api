# Task Automation API Documentation

## Overview

The Task Automation API is a FastAPI-based service that allows you to execute various server management and system administration tasks remotely. It's designed to be integrated with chatbots, mobile applications, or any client that can make HTTP requests, enabling you to manage your servers from anywhere.

## Table of Contents

1. [Installation and Setup](#installation-and-setup)
2. [Authentication](#authentication)
3. [API Endpoints](#api-endpoints)
4. [Task Types](#task-types)
5. [Usage Examples](#usage-examples)
6. [Integration with Chatbots](#integration-with-chatbots)
7. [Security Considerations](#security-considerations)
8. [Troubleshooting](#troubleshooting)

## Installation and Setup

### Prerequisites

- Python 3.7+
- Linux/Unix system (for system commands)
- Root/sudo access (for certain operations)

### Install Dependencies

```bash
pip install fastapi uvicorn psutil
```

### Configuration

1. **Set your API token** (required for security):
```bash
export API_TOKEN="your-super-secure-token-here"
```

2. **Save the API code** to a file (e.g., `task_api.py`)

3. **Run the server**:
```bash
python task_api.py
```

The API will be available at `http://localhost:8000`

### Production Deployment

For production, use a proper ASGI server:
```bash
pip install gunicorn
gunicorn -w 4 -k uvicorn.workers.UvicornWorker task_api:app --bind 0.0.0.0:8000
```

## Authentication

All protected endpoints require a Bearer token in the Authorization header:

```http
Authorization: Bearer your-api-token-here
```

If authentication fails, you'll receive a 401 Unauthorized response.

## API Endpoints

### Base Information

#### `GET /`
Returns basic API information.

**Response:**
```json
{
  "message": "Task Automation API",
  "status": "running"
}
```

#### `GET /health`
Health check endpoint (no authentication required).

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2025-08-10T14:30:00.123456"
}
```

### Protected Endpoints

#### `POST /execute`
Main endpoint for executing tasks.

**Request Body:**
```json
{
  "task_type": "task_name",
  "parameters": {
    "key": "value"
  }
}
```

**Response:**
```json
{
  "success": true,
  "message": "Task completed successfully",
  "data": {
    "additional": "information"
  },
  "timestamp": "2025-08-10T14:30:00.123456"
}
```

#### `GET /tasks`
Lists all available task types and their descriptions.

#### `GET /status`
Quick system status check.

## Task Types

### 1. restart_server

Restarts the server with a safety delay.

**Parameters:**
- `delay` (int, optional): Delay in seconds before restart (default: 5)
- `confirm` (bool, required): Must be `true` to confirm the restart

**Example:**
```json
{
  "task_type": "restart_server",
  "parameters": {
    "delay": 30,
    "confirm": true
  }
}
```

### 2. check_status

Gets comprehensive system status information.

**Parameters:** None required

**Returns:**
- CPU usage percentage
- Memory usage percentage
- Disk usage information
- System uptime
- Number of running processes

**Example:**
```json
{
  "task_type": "check_status"
}
```

### 3. restart_service

Restarts a system service using systemctl.

**Parameters:**
- `service_name` (string, required): Name of the service to restart

**Example:**
```json
{
  "task_type": "restart_service",
  "parameters": {
    "service_name": "nginx"
  }
}
```

### 4. check_disk_space

Checks disk space usage for a specified path.

**Parameters:**
- `path` (string, optional): Path to check (default: "/")

**Example:**
```json
{
  "task_type": "check_disk_space",
  "parameters": {
    "path": "/var/log"
  }
}
```

### 5. check_memory

Checks memory and swap usage.

**Parameters:** None required

**Returns:**
- Physical memory usage
- Swap memory usage
- Both in GB and percentage

**Example:**
```json
{
  "task_type": "check_memory"
}
```

### 6. run_command

Executes a whitelisted system command.

**Parameters:**
- `command` (string, required): Command to execute

**Whitelisted commands:**
- `ps`, `top`, `df`, `free`, `uptime`, `whoami`, `date`
- `systemctl status`, `docker ps`, `docker stats`

**Example:**
```json
{
  "task_type": "run_command",
  "parameters": {
    "command": "docker ps"
  }
}
```

### 7. check_logs

Retrieves recent log entries from a file.

**Parameters:**
- `log_file` (string, optional): Path to log file (default: "/var/log/syslog")
- `lines` (int, optional): Number of lines to retrieve (default: 50)

**Example:**
```json
{
  "task_type": "check_logs",
  "parameters": {
    "log_file": "/var/log/nginx/error.log",
    "lines": 100
  }
}
```

## Usage Examples

### Python Client

```python
import requests

API_BASE_URL = "http://your-server:8000"
API_TOKEN = "your-api-token"

headers = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
}

def execute_task(task_type, parameters=None):
    data = {
        "task_type": task_type,
        "parameters": parameters or {}
    }
    
    response = requests.post(
        f"{API_BASE_URL}/execute",
        headers=headers,
        json=data
    )
    
    return response.json()

# Check system status
status = execute_task("check_status")
print(f"CPU Usage: {status['data']['cpu_percent']}%")

# Restart nginx service
result = execute_task("restart_service", {"service_name": "nginx"})
print(result['message'])

# Check disk space
disk_info = execute_task("check_disk_space")
print(f"Free space: {disk_info['data']['free_gb']} GB")
```

### Curl Examples

```bash
# Check system status
curl -X POST "http://localhost:8000/execute" \
  -H "Authorization: Bearer your-token" \
  -H "Content-Type: application/json" \
  -d '{"task_type": "check_status"}'

# Restart a service
curl -X POST "http://localhost:8000/execute" \
  -H "Authorization: Bearer your-token" \
  -H "Content-Type: application/json" \
  -d '{"task_type": "restart_service", "parameters": {"service_name": "apache2"}}'

# Get available tasks
curl -X GET "http://localhost:8000/tasks" \
  -H "Authorization: Bearer your-token"
```

## Integration with Chatbots

### Discord Bot Example

```python
import discord
import requests
from discord.ext import commands

bot = commands.Bot(command_prefix='!')

@bot.command(name='server_status')
async def server_status(ctx):
    response = requests.post(
        "http://your-server:8000/execute",
        headers={"Authorization": "Bearer your-token"},
        json={"task_type": "check_status"}
    )
    
    data = response.json()
    if data['success']:
        status = data['data']
        await ctx.send(f"""
**Server Status:**
CPU: {status['cpu_percent']:.1f}%
Memory: {status['memory_percent']:.1f}%
Uptime: {status['uptime']}
""")

@bot.command(name='restart_nginx')
async def restart_nginx(ctx):
    response = requests.post(
        "http://your-server:8000/execute",
        headers={"Authorization": "Bearer your-token"},
        json={
            "task_type": "restart_service",
            "parameters": {"service_name": "nginx"}
        }
    )
    
    result = response.json()
    await ctx.send(result['message'])
```

### Slack Bot Integration

```python
from slack_bolt import App
import requests

app = App(token="your-slack-token")

@app.command("/server-status")
def server_status_command(ack, say, command):
    ack()
    
    response = requests.post(
        "http://your-server:8000/execute",
        headers={"Authorization": "Bearer your-token"},
        json={"task_type": "check_status"}
    )
    
    data = response.json()
    if data['success']:
        status = data['data']
        say(f"Server Status - CPU: {status['cpu_percent']}%, Memory: {status['memory_percent']}%")
```

## Security Considerations

### Important Security Measures

1. **Use Strong API Tokens**: Generate a long, random token and store it securely
2. **HTTPS in Production**: Always use HTTPS in production environments
3. **Firewall Configuration**: Restrict API access to authorized IP addresses
4. **Command Whitelisting**: The API only allows pre-approved safe commands
5. **Input Validation**: All inputs are validated using Pydantic models
6. **Logging**: All API calls are logged for audit purposes

### Recommended Security Setup

```bash
# Generate a secure random token
openssl rand -base64 32

# Set up firewall rules (example with ufw)
sudo ufw allow from 192.168.1.0/24 to any port 8000
sudo ufw deny 8000

# Use environment variables for tokens
echo 'export API_TOKEN="your-secure-token"' >> ~/.bashrc
```

### Reverse Proxy Configuration (Nginx)

```nginx
server {
    listen 443 ssl;
    server_name your-api-domain.com;
    
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
    
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Troubleshooting

### Common Issues

#### 1. Authentication Errors
**Problem**: 401 Unauthorized responses
**Solution**: Verify your API token is correctly set and included in requests

#### 2. Permission Denied Errors
**Problem**: Commands fail with permission errors
**Solution**: Ensure the API process has necessary permissions (may need sudo for some operations)

#### 3. Service Restart Failures
**Problem**: Service restart commands fail
**Solution**: Check that services exist and the API has systemctl permissions

#### 4. Connection Issues
**Problem**: Cannot connect to API
**Solution**: Verify the server is running and accessible on the specified port

### Debugging Tips

1. **Check API Logs**: The API logs all requests and errors
2. **Test with Curl**: Use curl to test endpoints directly
3. **Verify Permissions**: Ensure proper file and service permissions
4. **Check Firewall**: Verify firewall rules aren't blocking connections

### Log Locations

- **API Logs**: Check console output or configure logging to file
- **System Logs**: `/var/log/syslog` for general system events
- **Service Logs**: Use `journalctl -u service-name` for systemd services

## Advanced Usage

### Adding Custom Tasks

To add new task types:

1. Add to the `TaskType` enum
2. Create a handler method in `TaskHandler`
3. Add routing logic in the `/execute` endpoint

### Monitoring and Alerting

Integrate with monitoring systems:

```python
# Example: Send alerts when disk space is low
disk_info = execute_task("check_disk_space")
if disk_info['data']['percent_used'] > 90:
    send_alert("Disk space critical!")
```

### Batch Operations

Execute multiple tasks:

```python
def execute_health_check():
    tasks = [
        ("check_status", {}),
        ("check_disk_space", {}),
        ("check_memory", {})
    ]
    
    results = []
    for task_type, params in tasks:
        result = execute_task(task_type, params)
        results.append(result)
    
    return results
```

This documentation should get you started with using the Task Automation API effectively. Remember to always test in a safe environment before deploying to production!